# 日常髮廊：Render 部署來源

這個資料夾是準備上傳到私人 GitHub 儲存庫的乾淨來源，不包含本機預約資料、資料庫、管理密碼、簡訊金鑰或 Xcode 安裝產物。

- Render：Python Web Service，Free 方案。
- 資料庫：外部 PostgreSQL，例如 Neon。將連線資料放在 Render 的 DATABASE_URL，不放到程式碼或聊天。
- Blueprint 的 ADMIN_PASSWORD 使用 Render generateValue 產生。部署完成後由帳號擁有人在 Render Environment 安全查看；不是先前的本機示範密碼。
- 不會將本機測試客人或預約搬到公開資料庫。
- 客人入口為網站根網址，店家網頁後台為 /admin。
- iPhone 原生 App 的連線頁使用同一個根網址，不加 /admin。
- 目前尚未實際部署，帳號連接後才能建立服務及取得真實網址。

Render 免費服務會休眠，並有用量限制；免費 Render PostgreSQL 有到期限制，因此這份設定不建立 Render 免費資料庫。

官方說明：https://render.com/docs/free
