"""A small booking service: Python standard library locally; PostgreSQL on Render."""
import os, json, sqlite3, secrets, hashlib, hmac, time, threading, re, base64
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from pathlib import Path
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from http.cookies import SimpleCookie

ROOT = Path(__file__).parent
TZ = ZoneInfo('Asia/Taipei')
DATABASE_URL = os.getenv('DATABASE_URL', '')
IS_RENDER = bool(os.getenv('RENDER'))
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', '')
if IS_RENDER and (not DATABASE_URL or len(ADMIN_PASSWORD) < 12):
    raise RuntimeError('Render requires DATABASE_URL and ADMIN_PASSWORD (at least 12 characters).')
if not ADMIN_PASSWORD:
    raise RuntimeError('Set ADMIN_PASSWORD (at least 12 characters) before starting.')
if len(ADMIN_PASSWORD) < 12:
    raise RuntimeError('ADMIN_PASSWORD must have at least 12 characters.')
LOCK = threading.RLock()
ATTEMPTS = {}
SMS_ENABLED = all(os.getenv(k) for k in ("TWILIO_ACCOUNT_SID","TWILIO_AUTH_TOKEN","TWILIO_VERIFY_SERVICE_SID"))
DEFAULT = {
  "name": "日常髮廊",
  "tagline": "換個髮型，喜歡每一天",
  "description": "剪髮、染燙、護髮，交給懂你的設計師。為自己預留一段煥然一新的時間。",
  "address": "沙龍地址待設定",
  "contact": "沙龍電話與 LINE 待設定",
  "open": "10:00",
  "close": "19:00",
  "weekdays": [
    1,
    2,
    3,
    4,
    5,
    6
  ],
  "closedDates": [],
  "notice": "請提前 10 分鐘抵達。染燙服務請在備註告知髮長與近期漂染紀錄；實際方案與費用由設計師現場確認。以下為示範價格，可由後台修改。",
  "services": [
    {
      "id": "s1",
      "name": "設計剪髮",
      "description": "溝通臉型與日常習慣，打造好整理的專屬線條。",
      "duration": 60,
      "price": 800,
      "icon": "✂"
    },
    {
      "id": "s2",
      "name": "質感染髮",
      "description": "單色染髮與色彩諮詢，漂髮及長髮加價另議。",
      "duration": 150,
      "price": 2400,
      "icon": "◈"
    },
    {
      "id": "s3",
      "name": "造型燙髮",
      "description": "自然捲度與蓬鬆感，依髮況現場確認適合方案。",
      "duration": 180,
      "price": 3200,
      "icon": "〰"
    },
    {
      "id": "s4",
      "name": "深層護髮",
      "description": "為乾燥與染燙後髮絲補充保養，找回柔順光澤。",
      "duration": 60,
      "price": 1200,
      "icon": "✧"
    },
    {
      "id": "s5",
      "name": "洗髮造型",
      "description": "洗髮、吹整與簡單造型，清爽迎接每個重要日常。",
      "duration": 45,
      "price": 500,
      "icon": "❋"
    }
  ],
  "staff": [
    {
      "id": "p1",
      "name": "小日",
      "title": "剪裁・染髮設計師",
      "weekdays": [
        1,
        2,
        3,
        4,
        5,
        6
      ],
      "open": "10:00",
      "close": "19:00"
    },
    {
      "id": "p2",
      "name": "沐沐",
      "title": "燙髮・護髮設計師",
      "weekdays": [
        1,
        2,
        3,
        4,
        5,
        6
      ],
      "open": "10:00",
      "close": "19:00"
    }
  ],
  "faqs": [
    {
      "question": "如何預約設計師？",
      "keywords": "預約,設計師,預定",
      "answer": "先選剪髮、染髮、燙髮或護髮等服務，再指定設計師，選擇日期與空檔並填寫聯絡資料即可。每次預約選一項服務；若需要多項搭配，請先聯絡沙龍確認時間。"
    },
    {
      "question": "如何取消或改期？",
      "keywords": "取消預約,取消,改期,修改",
      "answer": "請到「我的預約」在服務開始前取消，時段會重新開放。改期請先取消，再預約新的時間；如需臨時協助請聯絡沙龍。"
    },
    {
      "question": "染髮需要漂髮嗎？",
      "keywords": "漂髮,漂色,染髮,染色",
      "answer": "是否需要漂髮會依目標髮色、髮況與染髮紀錄而定，請在備註說明想要的顏色與髮長。示範染髮價格不含漂髮，正式費用請與設計師確認。"
    },
    {
      "question": "燙髮需要多久？",
      "keywords": "燙髮,燙捲,燙直",
      "answer": "本店示範燙髮預約保留 180 分鐘；實際時間依髮長、髮況與造型調整。若有近期漂染紀錄，請提前告知設計師。"
    },
    {
      "question": "長髮需要加價嗎？",
      "keywords": "長髮,加價,髮長",
      "answer": "目前列出的價格為示範基本價格。長髮、漂髮或特殊設計的費用，請先聯絡沙龍確認，服務前會由設計師與你溝通。"
    },
    {
      "question": "怎麼付款？",
      "keywords": "付款,支付,刷卡,訂金",
      "answer": "目前採現場付款，實際收費與付款方式請向沙龍確認。網頁確認預約不會自動扣款。"
    }
  ]
}

def connect():
    if DATABASE_URL:
        import psycopg
        from psycopg.rows import dict_row
        return psycopg.connect(DATABASE_URL, row_factory=dict_row)
    db = sqlite3.connect(os.getenv('SQLITE_PATH', str(ROOT/'data.sqlite3')), timeout=15)
    db.row_factory = sqlite3.Row
    return db

def sql(db, q, args=()):
    return db.execute(q.replace('?', '%s') if DATABASE_URL else q, args)

def initialize():
    with connect() as db:
        for q in ["CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY, value TEXT NOT NULL)",
                  "CREATE TABLE IF NOT EXISTS bookings (id TEXT PRIMARY KEY, token_hash TEXT NOT NULL, day TEXT NOT NULL, start INTEGER NOT NULL, end_min INTEGER NOT NULL, staff_id TEXT NOT NULL, customer TEXT NOT NULL, phone TEXT NOT NULL, note TEXT NOT NULL, service_name TEXT NOT NULL, staff_name TEXT NOT NULL, price INTEGER NOT NULL, duration INTEGER NOT NULL, status TEXT NOT NULL, created TEXT NOT NULL)",
                  "CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, expires BIGINT NOT NULL)",
                  "CREATE TABLE IF NOT EXISTS phone_sessions (token_hash TEXT PRIMARY KEY, phone TEXT NOT NULL, expires BIGINT NOT NULL)"]:
            sql(db,q)
        sql(db,'CREATE INDEX IF NOT EXISTS bookings_schedule ON bookings(day, staff_id, status)')
        if not sql(db,'SELECT id FROM settings WHERE id=1').fetchone():
            sql(db,'INSERT INTO settings(id,value) VALUES(1,?)',(json.dumps(DEFAULT,ensure_ascii=False),))
        db.commit()

def config(db):
    return json.loads(sql(db,'SELECT value FROM settings WHERE id=1').fetchone()['value'])

def transaction(db):
    if DATABASE_URL:
        sql(db,'LOCK TABLE bookings, settings IN EXCLUSIVE MODE')
    else:
        sql(db,'BEGIN IMMEDIATE')

def minutes(s):
    if not isinstance(s,str) or not re.fullmatch(r'\d{2}:\d{2}',s): raise ValueError('時間格式錯誤')
    h,m=map(int,s.split(':'))
    if h>23 or m>59: raise ValueError('時間格式錯誤')
    return h*60+m

def clock(m): return f'{m//60:02d}:{m%60:02d}'
def digest(s): return hashlib.sha256(s.encode()).hexdigest()

def day_value(value):
    try: return datetime.strptime(value,'%Y-%m-%d').date()
    except (TypeError,ValueError): raise ValueError('日期格式錯誤')

def available(db,c,day,sid,pid):
    d=day_value(day); now=datetime.now(TZ)
    if d<now.date() or d>now.date()+timedelta(days=90): return []
    s=next((s for s in c['services'] if s['id']==sid),None)
    p=next((p for p in c['staff'] if p['id']==pid),None)
    if not s or not p: raise ValueError('請重新選擇服務或人員')
    if d.isoweekday() not in c['weekdays'] or d.isoweekday() not in p['weekdays'] or day in c['closedDates']: return []
    rows=sql(db,"SELECT start,end_min FROM bookings WHERE day=? AND staff_id=? AND status='confirmed'",(day,pid)).fetchall()
    first=max(minutes(c['open']),minutes(p['open'])); last=min(minutes(c['close']),minutes(p['close']))
    return [clock(t) for t in range(((first+29)//30)*30,last-s['duration']+1,30)
            if (d>now.date() or t>now.hour*60+now.minute) and not any(t<r['end_min'] and t+s['duration']>r['start'] for r in rows)]

def clean(value,n=200):
    if not isinstance(value,str): raise ValueError('欄位格式錯誤')
    value=value.strip()
    if len(value)>n: raise ValueError('輸入內容太長')
    return value

def validate_config(c):
    for k,n in [('name',40),('tagline',80),('description',300),('address',200),('contact',100),('notice',500)]:
        c[k]=clean(c.get(k,''),n)
    if not c['name']: raise ValueError('請填寫店名')
    if minutes(c['open'])>=minutes(c['close']): raise ValueError('結束時間必須晚於開始時間')
    for owner in [c]+c['staff']:
        if not isinstance(owner['weekdays'],list) or any(type(x)!=int or x<1 or x>7 for x in owner['weekdays']): raise ValueError('營業日設定錯誤')
    if not 1<=len(c['services'])<=30 or not 1<=len(c['staff'])<=20: raise ValueError('至少保留一項服務與一位人員')
    for group in ['services','staff']:
        ids=set()
        for item in c[group]:
            item['id']=clean(item['id'],50); item['name']=clean(item['name'],60)
            if not re.fullmatch(r'[a-zA-Z0-9_-]+',item['id']) or item['id'] in ids or not item['name']: raise ValueError('項目名稱或編號錯誤')
            ids.add(item['id'])
            if group=='services':
                if type(item['duration'])!=int or not 15<=item['duration']<=480 or type(item['price'])!=int or not 0<=item['price']<=1000000: raise ValueError('服務時長或價格不正確')
                item['description']=clean(item.get('description',''),200); item['icon']=clean(item.get('icon','✦'),4)
            else:
                item['title']=clean(item.get('title',''),60)
                if minutes(item['open'])>=minutes(item['close']): raise ValueError('人員下班時間必須晚於上班時間')
    if not isinstance(c['closedDates'],list) or len(c['closedDates'])>366: raise ValueError('公休日期過多')
    for d in c['closedDates']: day_value(d)
    if len(c['faqs'])>40: raise ValueError('常見問答最多 40 組')
    for f in c['faqs']:
        for k,n in [('question',100),('keywords',200),('answer',1000)]: f[k]=clean(f[k],n)
    return c


def normalize_phone(value):
    value=re.sub(r'[ ()-]','',clean(value,30))
    if re.fullmatch(r'09[0-9]{8}',value): value='+886'+value[1:]
    if not re.fullmatch(r'\+[1-9][0-9]{7,14}',value): raise ValueError('請輸入 09 開頭的台灣手機號碼，或含國碼的手機號碼')
    return value

def twilio_verify(action,fields):
    if not SMS_ENABLED: raise ValueError('簡訊登入尚未啟用，請使用預約管理碼查詢。')
    from urllib.parse import urlencode
    base='https://verify.twilio.com/v2/Services/'+os.environ['TWILIO_VERIFY_SERVICE_SID']
    auth=base64.b64encode((os.environ['TWILIO_ACCOUNT_SID']+':'+os.environ['TWILIO_AUTH_TOKEN']).encode()).decode()
    req=Request(base+'/'+action,data=urlencode(fields).encode(),headers={'Authorization':'Basic '+auth,'Content-Type':'application/x-www-form-urlencoded'})
    try:
        with urlopen(req,timeout=15) as response: return json.load(response)
    except (HTTPError,URLError,TimeoutError): raise ValueError('簡訊服務暫時無法完成驗證，請確認號碼、驗證碼或稍後重試。')

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(ROOT/'public'),**kw)
    def log_message(self,fmt,*args):
        # Do not log customer identifiers, phone numbers or cancellation tokens.
        pass
    def end_headers(self):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','same-origin')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
        super().end_headers()
    def respond(self,data,status=200,cookie=None):
        raw=json.dumps(data,ensure_ascii=False).encode()
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(raw)))
        if cookie: self.send_header('Set-Cookie',cookie)
        self.end_headers(); self.wfile.write(raw)
    def limited(self,key,limit,window,by_phone=False):
        # On Render use its trusted rightmost forwarded client address.
        ip=self.headers.get('X-Forwarded-For','').split(',')[-1].strip() if IS_RENDER else self.client_address[0]
        ident=("phone" if by_phone else ip,key); now=time.time()
        with LOCK:
            if len(ATTEMPTS)>10000:
                for k in list(ATTEMPTS):
                    if not ATTEMPTS[k] or ATTEMPTS[k][-1]<now-3600: ATTEMPTS.pop(k,None)
            hits=[x for x in ATTEMPTS.get(ident,[]) if x>now-window]
            if len(hits)>=limit: raise PermissionError('操作太頻繁，請稍後再試')
            ATTEMPTS[ident]=hits+[now]
    def admin(self,db):
        cookies=SimpleCookie()
        try: cookies.load(self.headers.get('Cookie','')); token=cookies['session'].value
        except (KeyError,ValueError): raise PermissionError('請先登入管理後台')
        if not sql(db,'SELECT token_hash FROM sessions WHERE token_hash=? AND expires>?',(digest(token),int(time.time()))).fetchone():
            raise PermissionError('登入已過期，請重新登入')
    def phone_user(self,db):
        cookies=SimpleCookie()
        try: cookies.load(self.headers.get('Cookie','')); token=cookies['phone_session'].value
        except (KeyError,ValueError): return None
        row=sql(db,'SELECT phone FROM phone_sessions WHERE token_hash=? AND expires>?',(digest(token),int(time.time()))).fetchone()
        return row['phone'] if row else None
    def do_GET(self):
        u=urlparse(self.path)
        if not u.path.startswith('/api/'):
            if u.path in ['/admin','/admin/']:
                page=(ROOT/'public'/'index.html').read_text().replace('/manifest.webmanifest','/admin.webmanifest').replace('<body>','<body class="admin-mode">').replace('<meta name="apple-mobile-web-app-title" content="日常髮廊">','<meta name="apple-mobile-web-app-title" content="沙龍管理">').replace('id="customer-view"','id="customer-view" hidden').replace('id="admin-view" class="admin-view" hidden','id="admin-view" class="admin-view"')
                raw=page.encode(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); return
            if u.path not in ['/','/index.html','/app.js','/style.css','/manifest.webmanifest','/admin.webmanifest','/icon.svg','/icon-192.png','/icon-512.png','/apple-touch-icon.png','/sw.js','/offline.html']:
                self.send_error(404); return
            return super().do_GET()
        try:
            with connect() as db:
                c=config(db); q=parse_qs(u.query)
                if u.path=='/api/config': return self.respond({'config':c,'today':datetime.now(TZ).date().isoformat(),'timezone':'Asia/Taipei','phone_login_enabled':SMS_ENABLED})
                if u.path=='/api/slots':
                    return self.respond({'slots':available(db,c,q.get('day',[''])[0],q.get('service',[''])[0],q.get('staff',[''])[0])})
                if u.path=='/api/admin/bookings':
                    self.admin(db)
                    rows=sql(db,'SELECT * FROM bookings ORDER BY day DESC,start DESC LIMIT 3000').fetchall()
                    return self.respond({'bookings':[{k:r[k] for k in r.keys() if k!='token_hash'} for r in rows]})
                if u.path=='/api/auth/status': return self.respond({'phone':self.phone_user(db),'enabled':SMS_ENABLED})
                if u.path=='/api/admin/session':
                    self.admin(db); return self.respond({'ok':True})
                if u.path=='/api/health': return self.respond({'ok':True})
                return self.respond({'error':'找不到頁面'},404)
        except PermissionError as e: self.respond({'error':str(e)},401)
        except (ValueError,KeyError,TypeError) as e: self.respond({'error':str(e)},400)
        except Exception: self.respond({'error':'服務暫時無法使用，請稍後重試'},500)
    def do_POST(self):
        try:
            origin=self.headers.get('Origin')
            if origin and urlparse(origin).netloc!=self.headers.get('Host'): raise PermissionError('請由本站操作')
            if not self.headers.get('Content-Type','').startswith('application/json'): raise ValueError('需要 JSON 格式')
            length=int(self.headers.get('Content-Length','0'))
            if length<=0 or length>65536: raise ValueError('資料長度不正確')
            b=json.loads(self.rfile.read(length))
            if not isinstance(b,dict): raise ValueError('資料格式錯誤')
            path=urlparse(self.path).path
            with connect() as db:
                c=config(db)
                if path=='/api/auth/start':
                    self.limited('sms-send',5,3600); phone=normalize_phone(b.get('phone',''))
                    # Apply both IP and phone limits; provider-side Verify controls remain enabled.
                    self.limited('sms-phone-'+digest(phone),3,600,by_phone=True)
                    result=twilio_verify('Verifications',{'To':phone,'Channel':'sms'})
                    if result.get('status')!='pending': raise ValueError('驗證碼無法送出，請稍後重試')
                    return self.respond({'ok':True,'phone':phone})
                if path=='/api/auth/verify':
                    self.limited('sms-check',10,900); phone=normalize_phone(b.get('phone','')); code=clean(b.get('code',''),10)
                    if not re.fullmatch(r'[0-9]{4,10}',code): raise ValueError('請輸入簡訊中的數字驗證碼')
                    result=twilio_verify('VerificationCheck',{'To':phone,'Code':code})
                    if result.get('status')!='approved': raise ValueError('驗證碼不正確或已過期，請重新確認')
                    token=secrets.token_urlsafe(32); lifetime=2592000 if b.get('remember') is True else 28800
                    sql(db,'DELETE FROM phone_sessions WHERE expires<?',(int(time.time()),))
                    sql(db,'INSERT INTO phone_sessions(token_hash,phone,expires) VALUES(?,?,?)',(digest(token),phone,int(time.time()+lifetime))); db.commit()
                    return self.respond({'ok':True,'phone':phone},cookie='phone_session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+str(lifetime)+('; Secure' if IS_RENDER else ''))
                if path=='/api/auth/logout':
                    cookies=SimpleCookie(); cookies.load(self.headers.get('Cookie',''))
                    if 'phone_session' in cookies: sql(db,'DELETE FROM phone_sessions WHERE token_hash=?',(digest(cookies['phone_session'].value),))
                    db.commit(); return self.respond({'ok':True},cookie='phone_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0')
                if path=='/api/admin/login':
                    self.limited('login',8,900)
                    pw=clean(b.get('password',''),200)
                    if not hmac.compare_digest(pw.encode(),ADMIN_PASSWORD.encode()): raise PermissionError('密碼不正確')
                    token=secrets.token_urlsafe(32)
                    lifetime=2592000 if b.get('remember') is True else 28800
                    sql(db,'DELETE FROM sessions WHERE expires<?',(int(time.time()),))
                    sql(db,'INSERT INTO sessions(token_hash,expires) VALUES(?,?)',(digest(token),int(time.time()+lifetime))); db.commit()
                    return self.respond({'ok':True},cookie='session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+str(lifetime)+('; Secure' if IS_RENDER else ''))
                if path=='/api/admin/logout':
                    self.admin(db)
                    cookie=SimpleCookie(); cookie.load(self.headers.get('Cookie',''))
                    sql(db,'DELETE FROM sessions WHERE token_hash=?',(digest(cookie['session'].value),)); db.commit()
                    return self.respond({'ok':True},cookie='session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0')
                if path=='/api/admin/config':
                    self.admin(db); updated=validate_config(b['config'])
                    transaction(db)
                    sql(db,'UPDATE settings SET value=? WHERE id=1',(json.dumps(updated,ensure_ascii=False),)); db.commit()
                    return self.respond({'ok':True,'config':updated})
                if path=='/api/admin/cancel':
                    self.admin(db); sql(db,"UPDATE bookings SET status='cancelled' WHERE id=?",(clean(b.get('id',''),40),)); db.commit()
                    return self.respond({'ok':True})
                if path=='/api/book':
                    self.limited('book',20,3600)
                    name=clean(b.get('name',''),60); phone=clean(b.get('phone',''),30); note=clean(b.get('note',''),500)
                    if len(name)<1 or not re.fullmatch(r'\+?[0-9 ()-]{8,25}',phone): raise ValueError('請填寫姓名與有效的聯絡電話')
                    phone=normalize_phone(phone)
                    signed_phone=self.phone_user(db)
                    if signed_phone and phone!=signed_phone: raise ValueError('預約電話需與目前登入的手機號碼相同，或先登出手機帳號')
                    sid=clean(b.get('service',''),50); pid=clean(b.get('staff',''),50); day=clean(b.get('day',''),10); at=clean(b.get('time',''),5)
                    transaction(db); c=config(db)
                    if at not in available(db,c,day,sid,pid): raise ValueError('這個時段已無法預約，請重新選擇')
                    s=next(s for s in c['services'] if s['id']==sid); p=next(p for p in c['staff'] if p['id']==pid)
                    ident='B'+secrets.token_hex(6).upper(); token=secrets.token_urlsafe(32); start=minutes(at)
                    record={'id':ident,'day':day,'start':start,'end_min':start+s['duration'],'staff_id':pid,'customer':name,'phone':phone,'note':note,'service_name':s['name'],'staff_name':p['name'],'price':s['price'],'duration':s['duration'],'status':'confirmed','created':datetime.now(TZ).isoformat()}
                    keys=list(record); sql(db,'INSERT INTO bookings('+','.join(keys)+',token_hash) VALUES('+','.join(['?']*(len(keys)+1))+')',tuple(record.values())+(digest(token),)); db.commit()
                    return self.respond({'booking':record,'token':token},201)
                if path=='/api/my-bookings':
                    self.limited('lookup',60,300)
                    entries=b.get('entries',[])
                    if not isinstance(entries,list) or len(entries)>100: raise ValueError('最多查詢 100 筆')
                    rows=[]
                    for item in entries:
                        r=sql(db,'SELECT * FROM bookings WHERE id=? AND token_hash=?',(clean(item['id'],40),digest(clean(item['token'],100)))).fetchone()
                        if r: rows.append({k:r[k] for k in r.keys() if k!='token_hash'})
                    signed_phone=self.phone_user(db)
                    if signed_phone:
                        local_phone='0'+signed_phone[4:] if signed_phone.startswith('+8869') else signed_phone
                        owned=sql(db,'SELECT * FROM bookings WHERE phone=? OR phone=? ORDER BY day DESC,start DESC LIMIT 100',(signed_phone,local_phone)).fetchall()
                        seen={r['id'] for r in rows}
                        rows.extend({k:r[k] for k in r.keys() if k!='token_hash'} for r in owned if r['id'] not in seen)
                    return self.respond({'bookings':rows})
                if path=='/api/cancel':
                    self.limited('cancel',30,300); transaction(db)
                    r=sql(db,'SELECT * FROM bookings WHERE id=? AND token_hash=?',(clean(b.get('id',''),40),digest(clean(b.get('token',''),100)))).fetchone()
                    signed_phone=self.phone_user(db)
                    if not r and signed_phone:
                        local_phone='0'+signed_phone[4:] if signed_phone.startswith('+8869') else signed_phone
                        r=sql(db,'SELECT * FROM bookings WHERE id=? AND (phone=? OR phone=?)',(clean(b.get('id',''),40),signed_phone,local_phone)).fetchone()
                    if not r: raise ValueError('找不到預約，請確認預約編號與管理碼')
                    now=datetime.now(TZ)
                    if r['day']<now.date().isoformat() or (r['day']==now.date().isoformat() and r['start']<=now.hour*60+now.minute): raise ValueError('預約已開始，請直接聯絡店家')
                    sql(db,"UPDATE bookings SET status='cancelled' WHERE id=?",(r['id'],)); db.commit(); return self.respond({'ok':True})
                if path=='/api/chat':
                    self.limited('chat',50,300); msg=clean(b.get('message',''),500)
                    if any(k in msg for k in ['營業','幾點','開門']):
                        days='、'.join('一二三四五六日'[d-1] for d in c['weekdays'])
                        answer=f"營業時間為週{days} {c['open']}–{c['close']}。公休日與各人員時段以預約頁顯示為準。"
                    elif any(k in msg for k in ['地址','位置','在哪','交通']): answer=c['address']
                    elif any(k in msg for k in ['電話','聯絡','真人']): answer=c['contact']
                    elif any(k in msg for k in ['價格','多少錢','費用','服務項目']): answer='\n'.join(f"{s['name']}：NT$ {s['price']:,}／{s['duration']} 分鐘" for s in c['services'])
                    else:
                        matches=[(max([len(k.strip()) for k in f['keywords'].split(',') if k.strip() and k.strip().lower() in msg.lower()] or [0]),i,f) for i,f in enumerate(c['faqs'])]
                        best=max(matches,key=lambda x:(x[0],x[1]),default=(0,0,None))
                        match=best[2] if best[0] else None
                        answer=match['answer'] if match else '這個問題需要店家協助確認。'+c['contact']+'。你也可以詢問營業時間、服務價格、地址或取消方式。'
                    return self.respond({'answer':answer})
                return self.respond({'error':'找不到頁面'},404)
        except PermissionError as e: self.respond({'error':str(e)},403)
        except (ValueError,KeyError,TypeError,StopIteration) as e: self.respond({'error':str(e) or '資料不正確'},400)
        except Exception: self.respond({'error':'系統暫時忙碌，請稍後重試；請勿連續重送預約'},500)

if __name__=='__main__':
    initialize()
    port=int(os.getenv('PORT','8765'))
    bind_host='0.0.0.0' if IS_RENDER else os.getenv('BIND_HOST','127.0.0.1')
    server=ThreadingHTTPServer((bind_host,port),Handler)
    print(f'Booking app ready: http://127.0.0.1:{port}',flush=True)
    server.serve_forever()
